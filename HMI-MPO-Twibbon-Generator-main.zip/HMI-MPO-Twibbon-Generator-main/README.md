# HMI-MPO Twibbon Generator

Generator Twibbon Untuk Organisasi Himpunan Mahasiswa Islam

Demo : http://hmimpo.fdci.se/
<img src="https://raw.githubusercontent.com/fdciabdul/HMI-MPO-Twibbon-Generator/main/IMG_20200815_121815-picsay.jpg">

Donate 😥 


